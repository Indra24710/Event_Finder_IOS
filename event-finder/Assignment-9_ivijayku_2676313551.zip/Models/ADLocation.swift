//
//  ADLocation.swift
//  event-finder
//
//  Created by Indra Kumar on 5/4/23.
//

import Foundation


struct ADLocationModel:Codable{
    let loc:String;
    
}
